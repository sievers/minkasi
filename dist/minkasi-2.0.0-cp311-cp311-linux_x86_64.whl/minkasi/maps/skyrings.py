import copy
import os
import sys
from typing import TYPE_CHECKING, Callable, List, Optional, Sequence, Tuple, Union

import numpy as np
from astropy import wcs
from astropy.io import fits
from numpy.typing import NDArray

from ..mapmaking.map2tod import map2tod
from ..mapmaking.tod2map import (
    tod2map_cached,
    tod2map_everyone,
    tod2map_omp,
    tod2map_simple,
)
from ..parallel import comm, get_nthread, have_mpi, nproc
from ..tools.py_fft import find_good_fft_lens
from .utils import get_wcs

if TYPE_CHECKING:
    from ..tods import Tod, TodVec

try:
    import healpy

    have_healpy = True
except ImportError:
    have_healpy = False

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

